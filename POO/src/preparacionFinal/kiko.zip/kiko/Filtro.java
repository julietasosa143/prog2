package preparacionFinal.kiko;

public abstract class Filtro {
    public abstract boolean cumple(Tarjeta t);
}
