package preparacionFinal.sportnow;

public abstract class Condicion {
    public abstract boolean cumple(Entrenamiento e);
}
