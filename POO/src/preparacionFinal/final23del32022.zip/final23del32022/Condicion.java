package preparacionFinal.final23del32022;

public abstract class Condicion {
    public abstract boolean cumple(Comida c);
}
