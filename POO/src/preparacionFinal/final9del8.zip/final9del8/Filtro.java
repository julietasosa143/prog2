package preparacionFinal.final9del8;

public abstract class Filtro {
    public abstract boolean cumple(OpcionMenu op);
}
