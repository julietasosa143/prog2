package preparacionFinal.final9del8;

public class FiltroIngrediente  extends Filtro{
    String ingBuscado;

    public FiltroIngrediente(String ing){
        ingBuscado = ing;
    }
    @Override
    public boolean cumple(OpcionMenu op){
        return op.getIngredientes().contains(ingBuscado);
    }
}
