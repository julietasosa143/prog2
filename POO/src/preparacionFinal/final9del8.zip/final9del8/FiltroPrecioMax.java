package preparacionFinal.final9del8;

public class FiltroPrecioMax extends Filtro{
    double precioMax;
    public FiltroPrecioMax(double precioMax) {
        this.precioMax = precioMax;
    }
    @Override
    public boolean cumple(OpcionMenu op){
        return op.getPrecio()<precioMax;
    }
}
