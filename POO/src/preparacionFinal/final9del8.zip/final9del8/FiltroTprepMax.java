package preparacionFinal.final9del8;

public class FiltroTprepMax extends Filtro{
    double tMax;

    public FiltroTprepMax(double tMax) {
        this.tMax = tMax;
    }
    @Override
    public boolean cumple(OpcionMenu op){
        return op.getTiempoPreparacion()<tMax;
    }
}
